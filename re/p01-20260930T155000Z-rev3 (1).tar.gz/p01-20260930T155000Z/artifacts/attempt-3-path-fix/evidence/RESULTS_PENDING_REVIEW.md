# P01 Formal Evidence — Review Required

The runner completed both configured SBY tasks with their expected SBY outcomes.
Before the formal gate is marked complete, inspect the generated SBY reports and
counterexample trace to record:

- compilation/elaboration success for both designs;
- identical property module and Boolean-input contract;
- reference assertion PASS;
- wrong-RTL assertion FAIL;
- actual legal `a`, `b`, and `sel` values in the counterexample;
- expected `y` and observed `y`;
- absence of undocumented assumptions.

Do not treat a shell exit status alone as certification evidence.
